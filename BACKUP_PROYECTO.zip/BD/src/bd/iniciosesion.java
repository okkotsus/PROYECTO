package bd;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class iniciosesion extends JFrame {
    private JTextField usernameField;
    private JPasswordField passwordField;
    public BD bd;

    public iniciosesion() { // Constructor corregido
        bd = new BD("hotel"); // Conexión a la base de datos
        setTitle("Iniciar Sesión");
        setSize(400, 250); // Tamaño de la ventana
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new GridBagLayout()); // Usar GridBagLayout para mejor control

        // Configuración de colores
        getContentPane().setBackground(new Color(240, 240, 240)); // Color de fondo amigable

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10); // Espaciado entre componentes
        gbc.fill = GridBagConstraints.HORIZONTAL; // Llenar el espacio horizontalmente

        JLabel usernameLabel = new JLabel("Usuario:");
        gbc.gridx = 0; // Columna
        gbc.gridy = 0; // Fila
        add(usernameLabel, gbc);

        usernameField = new JTextField(30); // Limitar a 30 caracteres para mayor amplitud
        gbc.gridx = 1; // Columna
        gbc.gridy = 0; // Fila
        gbc.weightx = 1.0; // Peso horizontal para que ocupe más espacio
        add(usernameField, gbc);

        JLabel passwordLabel = new JLabel("Contraseña:");
        gbc.gridx = 0; // Columna
        gbc.gridy = 1; // Fila
        add(passwordLabel, gbc);

        passwordField = new JPasswordField(30); // Limitar a 30 caracteres para mayor amplitud
        gbc.gridx = 1; // Columna
        gbc.gridy = 1; // Fila
        gbc.weightx = 1.0; // Peso horizontal para que ocupe más espacio
        add(passwordField, gbc);

        JButton loginButton = new JButton("Iniciar Sesión");
        loginButton.setBackground(new Color(100, 149, 237)); // Color de fondo del botón
        loginButton.setForeground(Color.WHITE); // Color del texto del botón
        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                login();
            }
        });
        gbc.gridx = 0; // Columna
        gbc.gridy = 2; // Fila
        gbc.gridwidth = 2; // Ocupa dos columnas
        add(loginButton, gbc);
    }

    private void login() {
        String username = usernameField.getText();
        String password = new String(passwordField.getPassword());

        // Validar las credenciales en la base de datos
        if (validarCredenciales(username, password)) {
            // Si las credenciales son correctas, abrir la ventana de gestión de clientes
            new CRUD().setVisible(true);
            this.dispose(); // Cerrar la ventana de inicio de sesión
        } else {
            // Si las credenciales son incorrectas, mostrar un mensaje de error
            JOptionPane.showMessageDialog(this, "Usuario o contraseña incorrectos. Intente de nuevo.");
            usernameField.setText("");
            passwordField.setText("");
        }
    }

    private boolean validarCredenciales(String username, String password) {
        Connection conn = bd.conectar();
        if (conn == null) {
            JOptionPane.showMessageDialog(this, "No se pudo conectar a la base de datos.");
            return false;
        }

        String sql = "SELECT * FROM empleados WHERE usuario = ? AND contraseña = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, username);
            pstmt.setString(2, password);
            try (ResultSet rs = pstmt.executeQuery()) {
                return rs.next(); // Si hay un resultado, las credenciales son válidas
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error al validar las credenciales: " + ex.getMessage());
            ex.printStackTrace();
            return false;
        } finally {
            bd.desconectar();
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable () {
            @Override
            public void run() {
                new iniciosesion().setVisible(true); // Cambiado a InicioSesion
            }
        });
    }
}