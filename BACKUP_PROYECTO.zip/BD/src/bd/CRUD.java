package bd;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.regex.Pattern;

public class CRUD extends JFrame {
    public JTextField idField, nombreField, paisField, emailField;
    public JTextArea resultArea;
    public BD bd;

    // Expresión regular para validar emails
    public static final String EMAIL_REGEX = 
        "^[a-zA-Z0-9_+&*-]+(?:\\.[a-zA-Z0-9_+&*-]+)*@" + 
        "(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,7}$";
    public static final Pattern EMAIL_PATTERN = Pattern.compile(EMAIL_REGEX);
    
    // Límite de caracteres para el nombre
    public static final int MAX_LONGITUD_NOMBRE = 50;

    public CRUD() {
        bd = new BD("hotel");
        createUI();
    }

    public void createUI() {
        setTitle("Gestión de Clientes");
        setSize(500, 400);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // Panel de entrada de datos
        JPanel inputPanel = new JPanel();
        inputPanel.setLayout(new GridLayout(5, 2));

        JLabel idLabel = new JLabel("ID del Cliente:");
        idField = new JTextField(10);
        JLabel nombreLabel = new JLabel("Nombre:");
        nombreField = new JTextField(10);
        JLabel paisLabel = new JLabel("País:");
        paisField = new JTextField(10);
        JLabel emailLabel = new JLabel("Email:");
        emailField = new JTextField(10);

        inputPanel.add(idLabel);
        inputPanel.add(idField);
        inputPanel.add(nombreLabel);
        inputPanel.add(nombreField);
        inputPanel.add(paisLabel);
        inputPanel.add(paisField);
        inputPanel.add(emailLabel);
        inputPanel.add(emailField);

        // Panel de botones
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new FlowLayout());

        JButton consultarButton = new JButton("Consultar");
        JButton agregarButton = new JButton("Agregar");
        JButton actualizarButton = new JButton("Actualizar");
        JButton eliminarButton = new JButton("Eliminar");
        JButton reservarButton = new JButton("Reservar Habitaciones"); // Nuevo botón

        buttonPanel.add(consultarButton);
        buttonPanel.add(agregarButton);
        buttonPanel.add(actualizarButton);
        buttonPanel.add(eliminarButton);
        buttonPanel.add(reservarButton); // Agregar el botón de reservar

        // Área de resultados
        resultArea = new JTextArea();
        resultArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(resultArea);

        // Agregar componentes a la ventana
        add(inputPanel, BorderLayout.NORTH);
        add(buttonPanel, BorderLayout.CENTER);
        add(scrollPane, BorderLayout.SOUTH);

        // Crear botón de cerrar sesión
        JButton logoutButton = new JButton("Cerrar Sesión");
        logoutButton.setIcon(new ImageIcon("path/to/shutdown_icon.png")); // Cambia la ruta al ícono de apagado
        logoutButton.setBackground(Color.WHITE);
        logoutButton.setForeground(Color.RED);
        logoutButton.setBorder(BorderFactory.createLineBorder(Color.RED, 2)); // Bordes rojos
        logoutButton.setPreferredSize(new Dimension(120, 30)); // Tamaño del botón

        // Panel para el botón de cerrar sesión
        JPanel logoutPanel = new JPanel();
        logoutPanel.setLayout(new FlowLayout(FlowLayout.LEFT));
        logoutPanel.add(logoutButton);

        // Agregar el panel de cerrar sesión a la esquina inferior izquierda
        add(logoutPanel, BorderLayout.SOUTH);

        // Acciones de los botones
        consultarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                consultarCliente();
            }
        });

        agregarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                agregarCliente(); // Llamar al método agregarCliente
            }
        });

        actualizarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                actualizarCliente();
            }
        });

        eliminarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                eliminarCliente();
            }
        });

        // Acción del botón de reservar habitaciones
        reservarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose(); // Cerrar la ventana actual
                new ReservarHbitaciones().setVisible(true); // Abrir la ventana de Reservar Habitaciones
            }
        });

        // Acción del botón de cerrar sesión
        logoutButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new iniciosesion().setVisible(true); // Asegúrate de que la clase InicioSesion esté disponible
                dispose(); // Cerrar la ventana actual
            }
        });
    }

    // Método para validar el formato del email
    public boolean validarEmail(String email) {
        if (email == null || email.isEmpty()) {
            return false;
        }
        return EMAIL_PATTERN.matcher(email).matches();
    }

    // Método para consultar un cliente
    public void consultarCliente() {
        String id = idField.getText();
        if (id.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Por favor, ingrese un ID de cliente.");
            return;
        }

        Connection conn = bd.conectar();
        if (conn == null) {
            JOptionPane.showMessageDialog(this, "No se pudo conectar a la base de datos.");
            return;
        }

        String sql = "SELECT id_Clientes, nombre, pais, email FROM clientes WHERE id_Clientes = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, id);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    String idCliente = rs.getString("id_Clientes");
                    String nombre = rs.getString("nombre");
                    String pais = rs.getString("pais");
                    String email = rs.getString("email");

                    resultArea.setText("ID Cliente: " + idCliente + "\nNombre: " + nombre + "\nPaís: " + pais + "\nEmail: " + email);
                } else {
                    resultArea.setText("No se encontró ningún cliente con el ID proporcionado.");
                }
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error al consultar la base de datos: " + ex.getMessage());
            ex.printStackTrace();
        } finally {
            bd.desconectar();
        }
    }

    // Método para agregar un cliente
    public void agregarCliente() {
        String nombre = nombreField.getText();
        String pais = paisField.getText();
        String email = emailField.getText();

        // Validar que los campos no estén vacíos
        if (nombre.isEmpty() || pais.isEmpty() || email.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Por favor, complete todos los campos.");
            return;
        }
        
        // Validar longitud del nombre
        if (nombre.length() > MAX_LONGITUD_NOMBRE) {
            JOptionPane.showMessageDialog(this, "Error: El nombre es demasiado largo.\n" +
                "Máximo permitido: " + MAX_LONGITUD_NOMBRE + " caracteres.");
            return;
        }
        
        // Validar formato del email
        if (!validarEmail(email)) {
            JOptionPane.showMessageDialog(this, "Error: El email no tiene un formato válido.\n" +
                "Debe contener un @ y un dominio válido (ejemplo: usuario@dominio.com)");
            return;
        }

        // Conectar a la base de datos
        Connection conn = bd.conectar();
        if (conn == null) {
            JOptionPane.showMessageDialog(this, "No se pudo conectar a la base de datos.");
            return;
        }

        // Preparar la consulta SQL para insertar el cliente
        String sql = "INSERT INTO clientes (nombre, pais, email) VALUES (?, ?, ?)";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, nombre);
            pstmt.setString(2, pais);
            pstmt.setString(3, email);
            pstmt .executeUpdate(); // Ejecutar la inserción
            JOptionPane.showMessageDialog(this, "Cliente agregado correctamente.");
            limpiarCampos(); // Limpiar los campos después de agregar
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error al agregar cliente: " + ex.getMessage());
            ex.printStackTrace();
        } finally {
            bd.desconectar(); // Asegurarse de desconectar
        }
    }

    // Método para actualizar un cliente
    public void actualizarCliente() {
        String id = idField.getText();
        String nombre = nombreField.getText();
        String pais = paisField.getText();
        String email = emailField.getText();

        if (id.isEmpty() || nombre.isEmpty() || pais.isEmpty() || email.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Por favor, complete todos los campos.");
            return;
        }
        
        // Validar longitud del nombre
        if (nombre.length() > MAX_LONGITUD_NOMBRE) {
            JOptionPane.showMessageDialog(this, "Error: El nombre es demasiado largo.\n" +
                "Máximo permitido: " + MAX_LONGITUD_NOMBRE + " caracteres.");
            return;
        }
        
        if (!validarEmail(email)) {
            JOptionPane.showMessageDialog(this, "Error: El email no tiene un formato válido.\n" +
                "Debe contener un @ y un dominio válido (ejemplo: usuario@dominio.com)");
            return;
        }

        Connection conn = bd.conectar();
        if (conn == null) {
            JOptionPane.showMessageDialog(this, "No se pudo conectar a la base de datos.");
            return;
        }

        String sql = "UPDATE clientes SET nombre = ?, pais = ?, email = ? WHERE id_Clientes = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, nombre);
            pstmt.setString(2, pais);
            pstmt.setString(3, email);
            pstmt.setString(4, id);
            int rowsUpdated = pstmt.executeUpdate();
            if (rowsUpdated > 0) {
                JOptionPane.showMessageDialog(this, "Cliente actualizado correctamente.");
                limpiarCampos();
            } else {
                JOptionPane.showMessageDialog(this, "No se encontró ningún cliente con el ID proporcionado.");
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error al actualizar cliente: " + ex.getMessage());
            ex.printStackTrace();
        } finally {
            bd.desconectar();
        }
    }

    // Método para eliminar un cliente
    public void eliminarCliente() {
        String id = idField.getText();
        if (id.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Por favor, ingrese un ID de cliente.");
            return;
        }

        Connection conn = bd.conectar();
        if (conn == null) {
            JOptionPane.showMessageDialog(this, "No se pudo conectar a la base de datos.");
            return;
        }

        String sql = "DELETE FROM clientes WHERE id_Clientes = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, id);
            int rowsDeleted = pstmt.executeUpdate();
            if (rowsDeleted > 0) {
                JOptionPane.showMessageDialog(this, "Cliente eliminado correctamente.");
                limpiarCampos();
            } else {
                JOptionPane.showMessageDialog(this, "No se encontró ningún cliente con el ID proporcionado.");
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error al eliminar cliente: " + ex.getMessage());
            ex.printStackTrace();
        } finally {
            bd.desconectar();
        }
    }

    // Método para limpiar los campos de entrada
    public void limpiarCampos() {
        idField.setText("");
        nombreField.setText("");
        paisField.setText("");
        emailField.setText("");
        resultArea.setText("");
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new CRUD().setVisible(true);
            }
        });
    }
}