package bd;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.sql.*;

public class ReservarHbitaciones extends JFrame {
    private JTextField clienteField, habitacionesField, tipoHabitacionField, fechaInicioField, fechaFinField, cantidadField;
    private BD bd;
    private JPanel habitacionesPanel;

    public ReservarHbitaciones() {
        bd = new BD("hotel");
        createUI();
        inicializarHabitaciones();
    }

    private void createUI() {
        setTitle("Reservar Habitaciones");
        setSize(400, 500);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        habitacionesPanel = new JPanel();
        habitacionesPanel.setLayout(new BoxLayout(habitacionesPanel, BoxLayout.Y_AXIS));
        habitacionesPanel.setAlignmentX(Component.CENTER_ALIGNMENT);
        add(habitacionesPanel, BorderLayout.NORTH);

        JPanel inputPanel = new JPanel();
        inputPanel.setLayout(new GridLayout(6, 2));

        inputPanel.add(new JLabel("Número de Cliente:"));
        clienteField = new JTextField();
        inputPanel.add(clienteField);

        inputPanel.add(new JLabel("Número de Habitación:"));
        habitacionesField = new JTextField();
        inputPanel.add(habitacionesField);

        inputPanel.add(new JLabel("Tipo de Habitación:"));
        tipoHabitacionField = new JTextField();
        inputPanel.add(tipoHabitacionField);

        inputPanel.add(new JLabel("Fecha de Inicio (YYYY-MM-DD):"));
        fechaInicioField = new JTextField();
        inputPanel.add(fechaInicioField);

        inputPanel.add(new JLabel("Fecha de Fin (YYYY-MM-DD):"));
        fechaFinField = new JTextField();
        inputPanel.add(fechaFinField);

        inputPanel.add(new JLabel("Cantidad de Habitaciones:"));
        cantidadField = new JTextField();
        inputPanel.add(cantidadField);

        JButton aceptarButton = new JButton("Aceptar");
        aceptarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                reservarHabitacion();
            }
        });

        JButton logoutButton = new JButton("Cerrar Sesión");
        logoutButton.setPreferredSize(new Dimension(140, 30));
        logoutButton.setBackground(Color.WHITE);
        logoutButton.setForeground(Color.RED);
        logoutButton.setFont(new Font("Arial", Font.BOLD, 12));
        logoutButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new iniciosesion().setVisible(true);
                dispose();
            }
        });

        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new FlowLayout(FlowLayout.CENTER));
        buttonPanel.add(aceptarButton);
        buttonPanel.add(logoutButton);

        add(inputPanel, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);
    }

    private void inicializarHabitaciones() {
        habitacionesPanel.removeAll();

        JLabel habitacionesLabel = new JLabel("Habitaciones Disponibles", SwingConstants.CENTER);
        habitacionesLabel.setFont(new Font("Arial", Font.BOLD, 16));
        habitacionesLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        habitacionesPanel.add(Box.createVerticalStrut(10));
        habitacionesPanel.add(habitacionesLabel);
        habitacionesPanel.add(Box.createVerticalStrut(10));

        for (int i = 1; i <= 10; i++) {
            JLabel habitacionLabel = new JLabel("Habitación " + i, SwingConstants.CENTER);
            habitacionLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
            habitacionLabel.setFont(new Font("Arial", Font.PLAIN, 14));

            boolean disponible = isHabitacionDisponible(i);
            habitacionLabel.setForeground(disponible ? Color.GREEN.darker() : Color.RED);
            habitacionLabel.setToolTipText(disponible ? "Disponible" : "Ocupada");

            habitacionesPanel.add(habitacionLabel);
            habitacionesPanel.add(Box.createVerticalStrut(5));
        }

        habitacionesPanel.revalidate();
        habitacionesPanel.repaint();
    }

    private boolean isHabitacionDisponible(int idHabitacion) {
        Connection conn = bd.conectar();
        if (conn == null) {
            return false;
        }

        String sqlCheckReservas = "SELECT COUNT(*) FROM reservacion WHERE id_habitacion = ?";

        try (PreparedStatement pstmt = conn.prepareStatement(sqlCheckReservas)) {
            pstmt.setInt(1, idHabitacion);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    int count = rs.getInt(1);
                    return count == 0;
                }
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            bd.desconectar();
        }
        return false;
    }

    private void reservarHabitacion() {
        String clienteId = clienteField.getText();
        String habitaciones = habitacionesField.getText();
        String tipoHabitacion = tipoHabitacionField.getText();
        String fechaInicio = fechaInicioField.getText();
        String fechaFin = fechaFinField.getText();
        String cantidad = cantidadField.getText();

        if (clienteId.isEmpty() || habitaciones.isEmpty() || tipoHabitacion.isEmpty() ||
                fechaInicio.isEmpty() || fechaFin.isEmpty() || cantidad.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Por favor, complete todos los campos.");
            return;
        }

        if (!isValidDate(fechaInicio) || !isValidDate(fechaFin)) {
            JOptionPane.showMessageDialog(this, "Las fechas deben estar en el formato YYYY-MM-DD.");
            return;
        }

        int idHabitacion = Integer.parseInt(habitaciones);
        if (!isHabitacionDisponibleParaFechas(idHabitacion, fechaInicio, fechaFin)) {
            JOptionPane.showMessageDialog(this, "La habitación " + idHabitacion + " no está disponible para las fechas seleccionadas.");
            return;
        }

        Connection conn = bd.conectar();
        if (conn == null) {
            JOptionPane.showMessageDialog(this, "No se pudo conectar a la base de datos.");
            return;
        }

        try {
            conn.setAutoCommit(false);
            double precioTotal = Integer.parseInt(cantidad) * 1000;

            String sqlReservacion = "INSERT INTO reservacion (id_clientes, t_habitacion, precio, f_inicio, f_fin, h_cantidad, id_habitacion) VALUES (?, ?, ?, ?, ?, ?, ?)";
            try (PreparedStatement pstmt = conn.prepareStatement(sqlReservacion)) {
                pstmt.setString(1, clienteId);
                pstmt.setString(2, tipoHabitacion);
                pstmt.setDouble(3, precioTotal);
                pstmt.setDate(4, Date.valueOf(fechaInicio));
                pstmt.setDate(5, Date.valueOf(fechaFin));
                pstmt.setInt(6, Integer.parseInt(cantidad));
                pstmt.setInt(7, idHabitacion);
                pstmt.executeUpdate();
            }

            conn.commit();

            JButton generarTicketButton = new JButton("Generar Ticket");
            generarTicketButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    generarTicketTxt(clienteId, habitaciones, tipoHabitacion, fechaInicio, fechaFin, cantidad, precioTotal);
                }
            });

            JOptionPane.showMessageDialog(this, generarTicketButton, "Reserva realizada correctamente", JOptionPane.INFORMATION_MESSAGE);

            limpiarCampos();
            inicializarHabitaciones();
        } catch (SQLException ex) {
            try {
                conn.rollback();
            } catch (SQLException e) {
                e.printStackTrace();
            }
            JOptionPane.showMessageDialog(this, "Error al realizar la reserva: " + ex.getMessage());
            ex.printStackTrace();
        } finally {
            bd.desconectar();
        }
    }

    private void generarTicketTxt(String clienteId, String habitaciones, String tipoHabitacion,
                                  String fechaInicio, String fechaFin, String cantidad, double precioTotal) {
        String userHome = System.getProperty("user.home");
        String desktopPath = userHome + File.separator + "Desktop";
        String fileName = "ticket_reserva_" + System.currentTimeMillis() + ".txt";
        File file = new File(desktopPath, fileName);

        try (PrintWriter writer = new PrintWriter(file)) {
            writer.println("===== Ticket de Reserva =====");
            writer.println("Cliente ID: " + clienteId);
            writer.println("Habitación: " + habitaciones);
            writer.println("Tipo de Habitación: " + tipoHabitacion);
            writer.println("Fecha de Inicio: " + fechaInicio);
            writer.println("Fecha de Fin: " + fechaFin);
            writer.println("Cantidad de Habitaciones: " + cantidad);
            writer.println("Precio Total: $" + precioTotal);
            writer.println("=============================");
            JOptionPane.showMessageDialog(this, "Ticket guardado como .txt en el escritorio.");
        } catch (IOException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error al guardar el ticket: " + e.getMessage());
        }
    }

    private boolean isHabitacionDisponibleParaFechas(int idHabitacion, String fechaInicio, String fechaFin) {
        Connection conn = bd.conectar();
        if (conn == null) {
            return false;
        }

        String sqlCheckReservas = "SELECT COUNT(*) FROM reservacion WHERE id_habitacion = ? " +
                "AND ((f_inicio <= ? AND f_fin >= ?) OR (f_inicio >= ? AND f_inicio <= ?) OR (f_fin >= ? AND f_fin <= ?))";

        try (PreparedStatement pstmt = conn.prepareStatement(sqlCheckReservas)) {
            pstmt.setInt(1, idHabitacion);
            pstmt.setString(2, fechaInicio);
            pstmt.setString(3, fechaFin);
            pstmt.setString(4, fechaInicio);
            pstmt.setString(5, fechaFin);
            pstmt.setString(6, fechaInicio);
            pstmt.setString(7, fechaFin);

            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    int count = rs.getInt(1);
                    return count == 0;
                }
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            bd.desconectar();
        }
        return false;
    }

    private boolean isValidDate(String date) {
        String regex = "\\d{4}-\\d{2}-\\d{2}";
        return date.matches(regex);
    }

    private void limpiarCampos() {
        clienteField.setText("");
        habitacionesField.setText("");
        tipoHabitacionField.setText("");
        fechaInicioField.setText("");
        fechaFinField.setText("");
        cantidadField.setText("");
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new ReservarHbitaciones().setVisible(true);
        });
    }
}
