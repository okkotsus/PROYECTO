package practicas;

import bd.BD;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Consulta extends JFrame {
    private JTextField idField;
    private JTextArea resultArea;
    private BD bd;

    public Consulta() {
        bd = new BD("hotel");
        createUI();
    }

    private void createUI() {
        setTitle("Consulta de Cliente");
        setSize(400, 300);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        JPanel panel = new JPanel();
        panel.setLayout(new FlowLayout());

        JLabel idLabel = new JLabel("ID del Cliente:");
        idField = new JTextField(10);
        JButton consultarButton = new JButton("Consultar");

        panel.add(idLabel);
        panel.add(idField);
        panel.add(consultarButton);

        resultArea = new JTextArea();
        resultArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(resultArea);

        add(panel, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);

        consultarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                consultarCliente();
            }
        });
    }

    public void consultarCliente() {
        String id = idField.getText();
        if (id.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Por favor, ingrese un ID de cliente.");
            return;
        }

        Connection conn = bd.conectar();
        if (conn == null) {
            JOptionPane.showMessageDialog(this, "No se pudo conectar a la base de datos.");
            return;
        }

        // Cambio en la consulta SQL para seleccionar id_Clientes, nombre y pais
        String sql = "SELECT id_Clientes, nombre, pais FROM clientes WHERE id_Clientes = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, id);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    String idCliente = rs.getString("id_Clientes");
                    String nombre = rs.getString("nombre");
                    String pais = rs.getString("pais");

                    // Mostrar id_Clientes, nombre y pais en el JTextArea
                    resultArea.setText("ID Cliente: " + idCliente + "\nNombre: " + nombre + "\nPaís: " + pais);
                } else {
                    resultArea.setText("No se encontró ningún cliente con el ID proporcionado.");
                }
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error al consultar la base de datos: " + ex.getMessage());
            ex.printStackTrace(); // Imprime el error en la consola para depuración
        } finally {
            bd.desconectar();
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new Consulta().setVisible(true);
            }
        });
    }
}