package practicas;

import java.util.HashMap;
import java.util.Map;
import java.util.logging.Logger;
import java.util.logging.Level;
import java.util.logging.Handler;
import java.util.logging.FileHandler;
import java.util.logging.SimpleFormatter;

public class CalculadorCostoHabitacion {
    private static final Logger logger = Logger.getLogger(CalculadorCostoHabitacion.class.getName());
    private static final Map<String, Double> tarifas = new HashMap<>();
    private final boolean debugMode;

    // Configuración inicial del logger
    static {
        try {
            // Desactivar logs en consola
            Logger rootLogger = Logger.getLogger("");
            for (Handler handler : rootLogger.getHandlers()) {
                rootLogger.removeHandler(handler);
            }
            
            // Configurar archivo de logs
            FileHandler fileHandler = new FileHandler("hotel.log");
            fileHandler.setFormatter(new SimpleFormatter());
            logger.addHandler(fileHandler);
            logger.setLevel(Level.ALL);
        } catch (Exception e) {
            System.err.println("Error configurando logger: " + e.getMessage());
        }
    }

    public CalculadorCostoHabitacion(boolean debugMode) {
        this.debugMode = debugMode;
        inicializarTarifas();
        if (debugMode) {
            logger.log(Level.CONFIG, "Calculador inicializado en modo debug");
        }
    }

    private void inicializarTarifas() {
        try {
            tarifas.put("STD", 100.0);   // Estándar
            tarifas.put("DLX", 150.0);   // Deluxe
            tarifas.put("SUITE", 250.0); // Suite
            tarifas.put("ECON", 80.0);   // Económica
            if (debugMode) {
                logger.log(Level.INFO, "Tarifas inicializadas: {0}", tarifas);
            }
        } catch (Exception e) {
            logger.log(Level.SEVERE, "Error al inicializar tarifas: {0}", e.getMessage());
            throw new RuntimeException("Error en inicialización de tarifas", e);
        }
    }

    public double calcularCosto(String codigoHabitacion, int noches) throws IllegalArgumentException {
        // Validación de parámetros nulos
        if (codigoHabitacion == null || codigoHabitacion.trim().isEmpty()) {
            String errorMsg = "Código de habitación no puede ser nulo o vacío";
            logger.log(Level.SEVERE, errorMsg);
            throw new IllegalArgumentException(errorMsg);
        }

        String codigoUpper = codigoHabitacion.toUpperCase();
        
        if (debugMode) {
            logger.log(Level.INFO, "Iniciando cálculo - Código: {0}, Noches: {1}", 
                    new Object[]{codigoUpper, noches});
        }

        // Validación mejorada de código de habitación
        if (!tarifas.containsKey(codigoUpper)) {
            String errorMsg = String.format("Código de habitación inválido: %s. Códigos válidos: %s", 
                    codigoUpper, tarifas.keySet());
            logger.log(Level.SEVERE, errorMsg);
            throw new IllegalArgumentException(errorMsg);
        }

        // Validación mejorada de noches
        if (noches <= 0) {
            String errorMsg = String.format("Número de noches inválido: %d. Debe ser mayor a 0", noches);
            logger.log(Level.SEVERE, errorMsg);
            throw new IllegalArgumentException(errorMsg);
        }

        // Cálculo con manejo de posibles errores numéricos
        try {
            double tarifa = tarifas.get(codigoUpper);
            double total = Math.round((tarifa * noches) * 100.0) / 100.0; // Redondeo a 2 decimales

            logger.log(Level.INFO, "Cálculo exitoso: {0} noches en {1} = ${2}", 
                    new Object[]{noches, codigoUpper, total});

            return total;
        } catch (Exception e) {
            String errorMsg = "Error en cálculo: " + e.getMessage();
            logger.log(Level.SEVERE, errorMsg);
            throw new RuntimeException(errorMsg, e);
        }
    }

    public static void main(String[] args) {
        try {
            CalculadorCostoHabitacion calculador = new CalculadorCostoHabitacion(true);
            
            // Casos de prueba válidos
            testCaso(calculador, "DLX", 3, 450.0);
            testCaso(calculador, "suite", 2, 500.0);
            testCaso(calculador, "ECON", 7, 560.0);
            
            // Casos de prueba inválidos
            testCaso(calculador, null, 1, 0);
            testCaso(calculador, "VIP", 2, 0);
            testCaso(calculador, "STD", -1, 0);
            testCaso(calculador, "", 5, 0);
            
        } catch (Exception e) {
            System.err.println("Error inesperado: " + e.getMessage());
        }
    }

    private static void testCaso(CalculadorCostoHabitacion calculador, 
                               String codigo, int noches, double esperado) {
        System.out.println("\nProbando: " + (codigo != null ? codigo : "null") + " por " + noches + " noches");
        try {
            double resultado = calculador.calcularCosto(codigo, noches);
            System.out.printf("Resultado: $%.2f%n", resultado);
            if (Math.abs(resultado - esperado) < 0.01 && esperado > 0) {
                System.out.println("✓ Prueba exitosa");
            } else if (esperado == 0) {
                System.out.println("X Se esperaba un error");
            } else {
                System.out.println("X Resultado inesperado");
            }
        } catch (Exception e) {
            if (esperado == 0) {
                System.out.println("✓ Error esperado: " + e.getMessage());
            } else {
                System.out.println("X Error inesperado: " + e.getMessage());
            }
        }
        System.out.println("------");
    }
}