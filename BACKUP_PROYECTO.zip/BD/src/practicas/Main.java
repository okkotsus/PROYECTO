package practicas;

import java.util.ArrayList;
import java.util.List;

// Clase Cliente
class Cliente {
    private String nombre;
    private String direccion;
    private String telefono;

    public Cliente(String nombre, String direccion, String telefono) {
        this.nombre = nombre;
        this.direccion = direccion;
        this.telefono = telefono;
    }

    public String getNombre() {
        return nombre;
    }

    public String getDireccion() {
        return direccion;
    }

    public String getTelefono() {
        return telefono;
    }

    @Override
    public String toString() {
        return "Cliente: " + nombre + "\nDirección: " + direccion + "\nTeléfono: " + telefono;
    }
}

// Clase Producto
class Producto {
    private String nombre;
    private double precio;
    private int cantidad;

    public Producto(String nombre, double precio, int cantidad) {
        this.nombre = nombre;
        this.precio = precio;
        this.cantidad = cantidad;
    }

    public String getNombre() {
        return nombre;
    }

    public double getPrecio() {
        return precio;
    }

    public int getCantidad() {
        return cantidad;
    }

    public double getTotal() {
        return precio * cantidad;
    }

    @Override
    public String toString() {
        return nombre + " - $" + precio + " x " + cantidad + " = $" + getTotal();
    }
}

// Clase Factura
class Factura {
    private Cliente cliente;
    private List<Producto> productos;
    private double total;

    public Factura(Cliente cliente) {
        this.cliente = cliente;
        this.productos = new ArrayList<>();
        this.total = 0.0;
    }

    public void agregarProducto(Producto producto) {
        productos.add(producto);
        total += producto.getTotal();
    }

    public void imprimirFactura() {
        System.out.println("=== Factura ===");
        System.out.println(cliente);
        System.out.println("\nProductos:");
        for (Producto producto : productos) {
            System.out.println(producto);
        }
        System.out.println("\nTotal a pagar: $" + total);
    }
}

// Clase Main (punto de entrada)
public class Main {
    public static void main(String[] args) {
        // Crear un cliente
        Cliente cliente = new Cliente("Juan Pérez", "Calle Falsa 123", "555-1234");

        // Crear algunos productos
        Producto producto1 = new Producto("Laptop", 1200.0, 1);
        Producto producto2 = new Producto("Mouse", 25.0, 2);
        Producto producto3 = new Producto("Teclado", 50.0, 1);

        // Crear una factura y agregar productos
        Factura factura = new Factura(cliente);
        factura.agregarProducto(producto1);
        factura.agregarProducto(producto2);
        factura.agregarProducto(producto3);

        // Imprimir la factura
        factura.imprimirFactura();
    }
}