package practicas;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;

public class Formulario extends JFrame{
    public Formulario(){
        setTitle("FORMULARIO REGISTRO");
        setSize(300,250);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        
        JPanel panel=new JPanel();
        panel.setLayout(new GridLayout(5,2,5,5));
        
        JLabel lblNombre= new JLabel("Nombre:");
        JTextField txtNombre=new JTextField();
        
        
        JLabel lblMail= new JLabel("Correo:");
        JTextField txtMail=new JTextField();
        
        
        JLabel lblTelefono= new JLabel("Telefono:");
        JTextField txtTelefono=new JTextField();
        
        
        JLabel lblEstadia= new JLabel("Tiempo de estadia(dias):");
        JTextField txtEstadia=new JTextField();
        
        JButton btnEnviar = new JButton("Enviar");
        
        btnEnviar.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e){
                String nombre =txtNombre.getText();
                String mail =txtMail.getText();
                String telefono =txtTelefono.getText();
                String estadia =txtEstadia.getText();
        
        if(nombre.isEmpty() || mail.isEmpty() || telefono.isEmpty() || estadia.isEmpty()){
           JOptionPane.showMessageDialog(null, "Todos los campos son obligatorios.","Error",JOptionPane.ERROR_MESSAGE);
           return;
        }        
           if(!mail.matches("[A-Za-z0-9+_.-]+@(.+)$")){
           JOptionPane.showMessageDialog(null, "El correo electronico no tiene un formato valido.","Error",JOptionPane.ERROR_MESSAGE);
           return;
            }
           try {
               Integer.parseInt(telefono);
               Integer.parseInt(estadia);
           }catch(NumberFormatException ex){
               JOptionPane.showMessageDialog(null, "El telefono y la estadia deben ser numeros.", "Error",JOptionPane.ERROR_MESSAGE);
               return;
           }
           JOptionPane.showMessageDialog(null, "Nombre:"+ nombre + "\nCorreo:"+ mail + "\nTelefono" + telefono + "\nEstadia:" + estadia +"dias", "Datos ingresados", JOptionPane.INFORMATION_MESSAGE);
            }
        });
    panel.add(lblNombre);
    panel.add(txtNombre);
    panel.add(lblMail);
    panel.add(txtMail);
    panel.add(lblTelefono);
    panel.add(txtTelefono);
    panel.add(lblEstadia);
    panel.add(txtEstadia);
    panel.add(new JLabel());
    panel.add(btnEnviar);
    
    add(panel);
    setVisible(true);
    }
    public static void main(String[]args){
        new Formulario();
    }
   
        }
    

    

