/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bd;

import java.sql.Connection;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author x
 */
public class BDTest {
    
    public BDTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    

    /**
     * Test of conectar method, of class BD.
     */
    @Test
    public void testConectar() {
        System.out.println("conectar");
        BD instance = null;
        Connection expResult = null;
        Connection result = instance.conectar();
        assertEquals(expResult, result);
    }

    /**
     * Test of desconectar method, of class BD.
     */
    @Test
    public void testDesconectar() {
        System.out.println("desconectar");
        BD instance = null;
        instance.desconectar();
    }

    /**
     * Test of main method, of class BD.
     */
    @Test
    public void testMain() {
        System.out.println("main");
        String[] args = null;
        BD.main(args);
    }
    
}
